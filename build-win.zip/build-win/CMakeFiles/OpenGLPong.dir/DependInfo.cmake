
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/tom/Desktop/Projects/OpenGL-Pong/src/glad.c" "CMakeFiles/OpenGLPong.dir/src/glad.c.obj" "gcc" "CMakeFiles/OpenGLPong.dir/src/glad.c.obj.d"
  "/home/tom/Desktop/Projects/OpenGL-Pong/src/main.cpp" "CMakeFiles/OpenGLPong.dir/src/main.cpp.obj" "gcc" "CMakeFiles/OpenGLPong.dir/src/main.cpp.obj.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
